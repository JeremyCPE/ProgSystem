#ifndef include_p1_h
#define include_p1_h

void p1();
#endif /* #ifndef __include_fichier_h__ */