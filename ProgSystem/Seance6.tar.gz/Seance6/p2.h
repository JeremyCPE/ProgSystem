#ifndef include_p2_h
#define include_p2_h
void p2();
#endif /* #ifndef __include_fichier_h__ */