#ifndef include_p2_h
#define include_p2_h

int get_rendez_vous();

#endif /* #ifndef __include_fichier_h__ */